v0.1.0 - First working version
v0.1.1 - cleaned writing to InfluxDB with use of "with". New "measurement" schema defined: 'AccelAnomaly'_'MachineName'
