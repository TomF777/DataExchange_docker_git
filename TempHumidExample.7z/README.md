v0.1.0 - First working version
v0.1.1 - cleaned writing to InfluxDB with use of "with". New "measurement" schema defined: 'TempHumidSensor_MachineName' . Ver 1.36.0 for influxdb-client
